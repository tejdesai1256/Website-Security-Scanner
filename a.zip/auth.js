// Authentication System
class AuthSystem {
    constructor() {
        this.users = this.loadUsers();
        this.currentUser = this.loadCurrentUser();
    }

    // Load users from localStorage
    loadUsers() {
        const stored = localStorage.getItem('users');
        if (stored) {
            return JSON.parse(stored);
        }
        // Default demo users
        return {
            'demo@example.com': {
                email: 'demo@example.com',
                password: this.hashPassword('Demo@123'),
                name: 'Demo User',
                createdAt: new Date().toISOString()
            }
        };
    }

    // Save users to localStorage
    saveUsers() {
        localStorage.setItem('users', JSON.stringify(this.users));
    }

    // Load current user session
    loadCurrentUser() {
        const stored = localStorage.getItem('currentUser');
        return stored ? JSON.parse(stored) : null;
    }

    // Save current user session
    saveCurrentUser(user) {
        this.currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
    }

    // Clear user session
    clearSession() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
    }

    // Simple hash function (for demo - in production use bcrypt)
    hashPassword(password) {
        // More reliable hash function using Base64 encoding
        return btoa(password);
    }

    // Validate email format
    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Validate password strength
    validatePassword(password) {
        const requirements = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /\d/.test(password),
            special: /[!@#$%^&*]/.test(password)
        };
        return requirements;
    }

    // Register new user
    register(email, password, confirmPassword, name) {
        const errors = [];

        // Validation
        if (!email || !password || !confirmPassword || !name) {
            errors.push('All fields are required');
        }

        if (!this.validateEmail(email)) {
            errors.push('Invalid email format');
        }

        if (this.users[email]) {
            errors.push('Email already registered');
        }

        if (password !== confirmPassword) {
            errors.push('Passwords do not match');
        }

        const passwordValidation = this.validatePassword(password);
        if (!passwordValidation.length) {
            errors.push('Password must be at least 8 characters long');
        }
        if (!passwordValidation.uppercase) {
            errors.push('Password must contain an uppercase letter');
        }
        if (!passwordValidation.lowercase) {
            errors.push('Password must contain a lowercase letter');
        }
        if (!passwordValidation.number) {
            errors.push('Password must contain a number');
        }
        if (!passwordValidation.special) {
            errors.push('Password must contain a special character (!@#$%^&*)');
        }

        if (errors.length > 0) {
            return { success: false, errors };
        }

        // Register user
        this.users[email] = {
            email,
            password: this.hashPassword(password),
            name,
            createdAt: new Date().toISOString(),
            scansRemaining: 100
        };

        this.saveUsers();

        return { success: true, message: 'Registration successful! Please log in.' };
    }

    // Login user
    login(email, password) {
        const errors = [];

        if (!email || !password) {
            errors.push('Email and password are required');
        }

        if (!this.validateEmail(email)) {
            errors.push('Invalid email format');
        }

        const user = this.users[email];
        if (!user) {
            errors.push('Invalid email or password');
            return { success: false, errors };
        }

        if (user.password !== this.hashPassword(password)) {
            errors.push('Invalid email or password');
            return { success: false, errors };
        }

        if (errors.length > 0) {
            return { success: false, errors };
        }

        // Create session
        const sessionUser = {
            email: user.email,
            name: user.name,
            createdAt: user.createdAt,
            scansRemaining: user.scansRemaining || 100,
            loginTime: new Date().toISOString()
        };

        this.saveCurrentUser(sessionUser);

        return { success: true, user: sessionUser };
    }

    // Logout user
    logout() {
        this.clearSession();
    }

    // Check if user is authenticated
    isAuthenticated() {
        return this.currentUser !== null;
    }

    // Get current user
    getCurrentUser() {
        return this.currentUser;
    }

    // Update user scans
    decrementScans(email) {
        if (this.users[email]) {
            this.users[email].scansRemaining = (this.users[email].scansRemaining || 100) - 1;
            this.saveUsers();
            
            if (this.currentUser && this.currentUser.email === email) {
                this.currentUser.scansRemaining = this.users[email].scansRemaining;
                this.saveCurrentUser(this.currentUser);
            }
        }
    }
}

// Initialize auth system
const auth = new AuthSystem();

// Redirect functions
function redirectToLogin() {
    window.location.href = 'login.html';
}

function redirectToDashboard() {
    window.location.href = 'dashboard.html';
}

function redirectToHome() {
    window.location.href = 'index.html';
}

// Check authentication and redirect if needed
function checkAuth(redirectIfNotAuth = true) {
    if (!auth.isAuthenticated()) {
        if (redirectIfNotAuth) {
            redirectToLogin();
        }
        return false;
    }
    return true;
}

// Protect page (run on page load)
function protectPage() {
    if (!checkAuth(true)) {
        return false;
    }
    return true;
}
